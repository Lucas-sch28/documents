﻿If($Args.count -eq 0)
{
    Write-Output "Aucun argument n'est specifié"
    exit 1
}

$file = Get-ChildItem $args[0]*.txt | Select-Object Name, Length
foreach($info in $file)
{
    Write-Output $info
}
