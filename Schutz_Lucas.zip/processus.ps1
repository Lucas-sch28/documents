﻿$process = Read-Host "Donnez moi le nom d'un processus en cours"
$nom = Get-Process | Where-Object {$_.ProcessName -eq $process}

If($nom -ne $null)
{
    Stop-Process $nom
    exit 0
}

echo "Le processus n'a pas été trouvé"