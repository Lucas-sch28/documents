﻿If($Args.count -eq 0)
{
    Write-Output "Aucun argument n'est specifié"
    exit 1
}
 
$chemin = Join-Path -Path $args[0] -ChildPath "services.scv"
Get-Service | Select-Object Name, Status | Out-file -FilePath $chemin



