﻿Write-Output "1. Afficher le date et l'heure"
Write-Output "2. Lister les 5 processus les plus gourmands en mémoire"
Write-Output "3. Lister les 5 plus gros fichiers dans C:\USers"
Write-Output "4. Quitter"
$nbr = read-host


If($nbr -eq 1)
{
    Get-Date
}

If($nbr -eq 2)
{
    $processus = Get-Process | Sort-Object -Property WS -Descending
    for($i=0; $i -lt 5; $i++)
    {
        $processus[$i]
    }
}

If($nbr -eq 3)
{
    $fichiers = Get-ChildItem C:\Users -Recurse | Sort-Object -Property Length -Descending
    for($i=0; $i -lt 5; $i++)
        {
           $fichiers[$i]
        }
}

If($nbr -eq 4)
{
    exit 1
}