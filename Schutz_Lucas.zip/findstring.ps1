﻿$chaine = read-host "Donnez moi une chaine de caractères"
$chemin = read-host "Donnez moi un répértoire"

Get-ChildItem -Path $chemin *$chaine*.txt 
