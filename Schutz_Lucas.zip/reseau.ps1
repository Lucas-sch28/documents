﻿$ipv4 = (Get-NetIPAddress -AddressFamily IPv4).IPAddress
echo "Ces adresses sont des adresses IPv4 :" $ipv4

$ipv6 = (Get-NetIPAddress -AddressFamily IPv6).IPAddress
echo "Ces adresses sont des adresses IPv6 :" $ipv6


