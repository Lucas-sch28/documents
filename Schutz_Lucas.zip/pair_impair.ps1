﻿[int]$nbr = Read-Host "Entrez un nombre"

If([int]$nbr % 2 -eq 0)
{
    Write-Output "Le nombre est pair"
}
Else
{
    Write-Output "Le nombre est impair"
}
