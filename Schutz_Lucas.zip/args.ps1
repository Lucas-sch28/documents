﻿$Args | Out-string
