New-Item -Path . -Name "audit.csv" -ItemType File

$info = systeminfo

write-output $info[1] >> audit.csv
write-output $info[2] >> audit.csv
write-output $info[26] >> audit.csv
write-output $info[24] >> audit.csv
write-output $info[25] >> audit.csv

