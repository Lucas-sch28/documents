﻿If($Args.count -eq 0)
{
    Write-Output "Aucun argument n'est specifié"
    exit 1
}


for($i=0; $i -lt 11; $i++)
{
    [int]$args[0] * [int]$i
}