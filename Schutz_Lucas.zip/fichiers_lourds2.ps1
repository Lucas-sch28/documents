﻿If($Args.count -eq 0)
{
    Write-Output "Aucun argument n'est specifié"
    exit 1
}

$fichiers = Get-ChildItem $args[0] -Recurse | Sort-Object -Property Length -Descending
for($i=0; $i -lt 10; $i++)
{
    $fichiers[$i]
}