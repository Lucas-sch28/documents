﻿New-Item -Path . -Name "reseau.log" -ItemType File

$ip = read-host "Donnez moi une IP/domaine"

for($i=0 ; $i -le 5 ; $i++)
{
    ping $ip >> reseau.log
    Start-Sleep -Seconds 10
}