﻿$ligne = Get-LocalUser

foreach($actif in $ligne)
{
    if($actif.Enabled.ToString() -eq "False")
    {
        Write-Output "Le compte $actif est désactivé"
    }
    ElseIf($actif.Enabled.ToString() -eq "True")
    {
        Write-Output "Le compte $actif est activé"
    }
}