﻿$tableau = @("Zakaria", "Joel", "Christian", "Lucas", "Julien")
$tableau | Sort-Object | Out-string
