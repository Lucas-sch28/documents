﻿$process = Get-Process | Select-Object ProcessName, Id, CPU
foreach($info in $process)
{
    Write-Output $info
}
