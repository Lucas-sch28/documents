﻿get-command | Out-String
Write-output $PSVersionTable