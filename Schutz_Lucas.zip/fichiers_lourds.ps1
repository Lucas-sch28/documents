﻿If($Args.count -eq 0)
{
    Write-Output "Aucun argument n'est specifié"
    exit 1
}

$fichiers = Get-ChildItem $args[0] | Where-Object {$_.length -gt "1MB"}
Write-Output "$fichiers"
