﻿If($Args.count -eq 0)
{
    Write-Output "Aucun service n'est specifié"
    exit 1
}

If(Get-Service -name $args[0] | Where-Object {$_.status -eq "Running"})
{
    Write-Output "Le service est demarré"
}
Else
{
    Write-Output "Le service n'est pas demarré"
}
