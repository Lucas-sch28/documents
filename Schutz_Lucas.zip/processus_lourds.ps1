﻿$processus = Get-Process | Where-Object {$_.WS -ge "100Mb"}
Write-Output "$processus"

