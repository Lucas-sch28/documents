﻿Write-Output $env:USERNAME
Write-output $env:OS
Write-Output $PWD